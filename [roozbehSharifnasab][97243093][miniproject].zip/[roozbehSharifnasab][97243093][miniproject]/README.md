# sbu_2cars
mini project of sbu basic programming for winter 97 (2cars)
for run program, open terminal in program folder and : make run

